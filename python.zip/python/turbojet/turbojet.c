#include <stdio.h>
#include <math.h>

int main() {
    FILE *fp;
    //varios efficiency
    double e_d = 0.97;
    double e_c = 0.85;
    double e_m = 1;

    double e_b = 1;
    double e_t = 0.9;
    double e_n = 0.98;
//properties of air and gas
    double g_a = 1.4;
    double g_g = 1.33;
    double cp_a = 1005;
    double cp_g = 1147;
    int rp_c = 2;//pressure ratio
    //int T03 = 1200;
    double R = 287;
    double m = 0.85;
    int pa = 18750;
    int Ta = 216.7;
    double a[3]={1200,1400,1600};
    double c = sqrt(g_a*R*Ta);
    double ca = m*c;
    fp = fopen("output1.txt", "w");
    for(int i=0;i<3;i++){
double            T03=a[i];
    for(rp_c=2;rp_c<=100;rp_c+=2) {
            //calculation in diffuser
        double T0a = Ta + (ca*ca)/(2*cp_a);
        double T01 = T0a;
        double T01s = e_d*(T01-Ta)+Ta;
        double p01s = pa*pow((T01s/Ta), (g_a/(g_a-1)));
        double p01 = p01s;
    //calculation in compressor
        double p02 = p01*rp_c;
        double T02s = T01*pow(rp_c, ((g_a-1)/g_a));
        double T02 = ((T02s - T01)/e_c) + T01;
//        calculation in turbine
        double T04 = T03 - cp_a*(T02-T01)/(e_m*cp_g);
        double T04s = T03 - (T03 - T04)/e_t;
        double p03 = p02;
        double p04 = p03*pow((T04s/T03), (g_g/(g_g-1)));
        double pc = p04*pow((1 - (g_g-1)/(e_n*(g_g+1))), (g_g/(g_g-1)));
        //calculation  in nozzle
        double p5, T5s, T5, c5, rho_5, fs, f, sfc;
        if(pc > pa) {
            p5 = pc;
            T5 = T04*(2/(g_g+1));
            c5 = sqrt(g_g*R*T5);
        }
        else {
            p5 = pa;
            T5s = T04*pow((p04/pa), ((g_g-1)/(g_g)));
            T5 = T04 - e_n*(T04-T5s);
            c5 = sqrt(2*cp_g*(T04-T5));
        }
        rho_5 = p5/(R*T5);
        fs = (c5 - ca) + (p5-pa)/(rho_5*c5);
        f = (cp_a*T02-cp_g*T03)/(cp_g*T03-43100000);
        sfc = f/fs;
        fprintf(fp, "%d\t\t%.3f\t\t%.3f\n", rp_c, fs/1000, sfc*1000);
        printf("%d\t\t%.3f\t\t%.3f\n", rp_c, fs/1000, sfc*1000);

    }
printf("\n");
fprintf(fp,"\n");
    }
    return 0;
}
