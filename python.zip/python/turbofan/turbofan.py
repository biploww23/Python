#all given data
#efficiency of different terms
e_d,e_f,e_fn,e_c,e_b,e_t,e_n,e_m= 0.97,0.85,0.97,0.85,1,0.9,0.98,1          #diffuser efficiency
#gamma values
g_a,g_g = 1.4,1.33
rp_f = 1.50         #fan pressure ratio
m = 0.85            #mach no.
pa = 18750          #atmospheric pressure in pa
Ta = 216.7          #atmospheric temprature
R = 287             #gas constant in j/kg-k
cp_a,cp_g = 1005,1147        
T04 = 1600          
c = (g_a*R*Ta)**0.5     #sonic velocity
ca = m*c                #aircraft velocity
f = open(f"output.txt","w")
a = [4,5,6]
i=0
while(i<=2):
    b = a[i]
    rp_c = 2            #compressor pressure ratio
    while(rp_c<=100):
        #diffuser calculation
        T0a = Ta + (ca**2)/(2*cp_a)
        T01 = T0a
        T01s = e_d * (T01-Ta)+Ta
        p01s = pa*(T01s/Ta)**(g_a/(g_a-1))
        p01 = p01s
        #f calculationan
        p02 = p01*rp_f
        T02s = T01*rp_f**((g_a-1)/(g_a))
        T02 = ((T02s-T01)/e_f)+T01
        T08 = T02
        #nozzle calculation
        pc_c = p02*(1-(1/e_n)*((g_a-1)/(g_a+1)))**(g_a/(g_a-1))
        if(pc_c>pa):
            p8 = pc_c
            T8 = 2*T08/(g_a+1)                  #chocked nozzle condition
            c8 = (g_a*R*T8)**0.5
        else:
            p8 = pa
            T8s = T02*(p02/pa)**((g_a-1)/(g_a))
            T8 = T08-e_n*(T02-T8s)
            c8 = (2*cp_a*(T08-T8))**0.5
        #mass flow rates
        mc = b/(b+1)            #mass flow rate of cold air
        mh = 1/(b+1)            #mass flow rate of hot air
        #calculations compressor
        p03 = p02*rp_c
        T03s = T02*rp_c**((g_a-1)/g_a)
        T03 = T02 + e_c*(T03s-T02)
        #for high pressure turbine
        T05 = T04 - cp_a*(T03-T02)/(e_m*cp_g)
        T05s = ((T05-T04)/(e_t))+T04
        p04 = p03
        p05 = p04*(T05s/T04)**(g_g/(g_g-1))
        #for low pressure turbine
        T06 = T05-cp_a*(1+b)*(T02-T01)/(cp_g*e_m) 
        T06s = T05-(T05-T06)/e_t
        p06 = p05*(T06s/T05)**(g_g/(g_g-1))
        #for hot nozzle
        pc_h = p06*(1-(g_g-1)/(e_n*(g_g+1)))**((g_g)/(g_g-1))
        if(pc_h>pa):
            p9 = pc_h
            T09 = T02
            T9 = 2*T09/(g_g+1)
            c9 = (g_g*R*T9)**0.5
        else:
            p9 = pa
            T09 = T02
            T9 = T06-e_n*(T06-Ta)
            c9 = (2*cp_g*(T09-T9))**0.5
        rho9 = p9/(R*T9)
        rho8 = p8/(R*T8)
        f =(cp_a*(T03)-cp_g*(T04))/(cp_g*T03-43100000)          #fuel air ratio
        st_c = (c8-ca)+(p8-pa)/(rho8*mc)                        #specific thrust due to cold air
        st_h = (c9-ca)+(p9-pa)/(rho9*mh)                        #specific thrust due to hot air
        st = st_c+st_h                                          #specific thrust
        sfc = f/st                                              #specific fuel consumption
        print(rp_c,end="    ")
        print(st/1000,end="    ")
        print(sfc*1000*3600)
    
        with open("output2.txt","a") as f:
            f.write(f"{rp_c}\t\t{(st/1000):.3f}\t\t{(sfc*1000*3600):.8f}\n")
        rp_c=rp_c+2
    print("\n\n\n")
    with open("output2.txt","a") as f:
            f.write("\n")
    i = i+1













